# LudumDare35
~ zirconcode

Play:
distr/play.html 
(locally run java applet, yes I'm sorry it's a java applet)

Source and Stuff:
https://github.com/ZirconCode/LudumDare35

---

Only had around 10 hours, really happy with the mechanics, unhappy with the levels and polish. Good Enough =)


It should be playable until at least level 8. The score is based on volume.


Controls: WASD to move, F to toggle freeze, H to advance level when conditions met. Touch all the green thingies and none of the red to win. Drag with the mouse to morph the nearest node of your hexagon. 


Have fun and post your highscores!

----

Needs: level editor, player shape editor, polish. Some soap after viewing the code.
